Please go to https://github.com/JackMD/ScoreHud/tree/master#addons to learn more about addons.

You can download more from here https://github.com/JackMD/ScoreHud/tree/addons

Also please note that if you dont find a addon you are looking for then ask the author of the plugin to make addon for score hud. I wont be making addons for their plugins anymore.

Please read the readme here too https://github.com/JackMD/ScoreHud/blob/master/README.md